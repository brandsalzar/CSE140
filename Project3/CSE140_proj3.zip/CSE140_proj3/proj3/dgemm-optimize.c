void dgemm( int m, int n, float *A, float *C )
{
// FILL-IN 
  
}
